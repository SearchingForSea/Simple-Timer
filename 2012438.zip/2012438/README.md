# countdown

## Project setup

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn serve
```

### Compiles and minifies for production

```
yarn build
```

### Lints and fixes files

```
yarn lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

# 正常打开，进入countdown文件夹，输入以下命令

```
npm run serve
```

均正常操作，打开后点击按钮响应事件
